package com.mps.sampler

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicIntegerArray
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh

class MainActivity : Activity() {

    private val ORANGE = Color.parseColor("#FF6A00")
    private val BG = Color.parseColor("#111114")
    private val PANEL = Color.parseColor("#26262C")
    private val RED = Color.parseColor("#C62828")
    private val PAD_COLORS = intArrayOf(
        0xFFE53935.toInt(), 0xFFFB8C00.toInt(), 0xFFFDD835.toInt(), 0xFF43A047.toInt()
    )

    // ---- audio engine state ----
    private var sampleRate = 48000
    private var framesPerBuf = 256
    private val samples = Array(16) { ShortArray(0) }
    private val playPos = AtomicIntegerArray(16).also { for (i in 0 until 16) it.set(i, -1) }
    @Volatile private var running = true
    private var audioThread: Thread? = null
    private val ui = Handler(Looper.getMainLooper())

    // ---- mixer ----
    private val vol = FloatArray(16) { 0.8f }
    private val pan = FloatArray(16)          // -1 (L) .. +1 (R)
    private val lGain = FloatArray(16)
    private val rGain = FloatArray(16)

    private val names = arrayOf(
        "KICK", "SNARE", "HAT C", "HAT O", "CLAP", "TOM L", "TOM H", "RIM",
        "COWBELL", "CRASH", "BASS", "BASS 2", "PERC", "ZAP", "CONGA", "SHAKER"
    )
    private val pattern = Array(16) { BooleanArray(16) }

    private var selected = 0
    @Volatile private var bpm = 100
    @Volatile private var swing = 0
    private var rec = false
    private var loadMode = false
    private var mixMode = false
    private var pickingPad = -1

    // mic sampling
    @Volatile private var micRecording = false
    @Volatile private var micStop = false

    @Volatile private var playing = false
    @Volatile private var step = 0
    @Volatile private var lastStepNs = 0L
    @Volatile private var curStepNs = 1L

    private lateinit var padViews: Array<TextView>
    private lateinit var stepViews: Array<TextView>
    private lateinit var bpmView: TextView
    private lateinit var playBtn: TextView
    private lateinit var recBtn: TextView
    private lateinit var micBtn: TextView
    private lateinit var loadBtn: TextView
    private lateinit var mixBtn: TextView
    private lateinit var swingBtn: TextView
    private lateinit var mixPanel: LinearLayout
    private lateinit var mixTitle: TextView
    private lateinit var volBar: SeekBar
    private lateinit var panBar: SeekBar

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(color: Int, stroke: Int = 0, radius: Int = 10) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat()
        setColor(color)
        if (stroke != 0) setStroke(dp(3), stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        sampleRate = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        framesPerBuf = am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256

        for (i in 0 until 16) samples[i] = synth(i)

        // balanced default levels
        vol[0] = 0.9f; vol[2] = 0.55f; vol[3] = 0.55f; vol[9] = 0.5f
        vol[10] = 0.85f; vol[11] = 0.85f; vol[15] = 0.5f; vol[7] = 0.7f
        pan[2] = -0.25f; pan[3] = 0.25f; pan[5] = -0.4f; pan[6] = 0.4f; pan[9] = 0.3f; pan[15] = 0.35f
        for (i in 0 until 16) updateGain(i)

        for (s in 0 until 16 step 4) pattern[0][s] = true
        pattern[1][4] = true; pattern[1][12] = true
        for (s in 0 until 16 step 2) pattern[2][s] = true

        buildUi()
        startAudio()
        refresh()
    }

    private fun updateGain(p: Int) {
        val a = (pan[p] + 1f) * (PI.toFloat() / 4f)   // equal-power pan
        lGain[p] = vol[p] * cos(a)
        rGain[p] = vol[p] * sin(a)
    }

    // ---------------- audio engine (stereo, sample-accurate sequencer) ----------------
    private fun stepLen(i: Int): Double {
        val base = sampleRate * 60.0 / bpm / 4.0
        val sw = swing / 100.0
        return if (i % 2 == 0) base * (1.0 - sw) else base * (1.0 + sw)
    }

    private fun fire(s: Int) {
        step = s
        lastStepNs = System.nanoTime()
        curStepNs = (stepLen(s) / sampleRate * 1e9).toLong()
        for (p in 0 until 16) if (pattern[p][s]) playPos.set(p, 0)
        ui.post { refresh() }
    }

    private fun startAudio() {
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
            )
            .setBufferSizeInBytes(max(minBuf, framesPerBuf * 2 * 2 * 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track.play()

        audioThread = thread(isDaemon = true, priority = Thread.MAX_PRIORITY) {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val chunk = framesPerBuf
            val buf = ShortArray(chunk * 2)
            var idx = -1
            var acc = 0.0
            while (running) {
                for (i in 0 until chunk) {
                    if (playing) {
                        if (idx < 0) {
                            idx = 0; acc = 0.0; fire(0)
                        } else {
                            val len = stepLen(idx)
                            if (acc >= len) { acc -= len; idx = (idx + 1) % 16; fire(idx) }
                        }
                        acc += 1.0
                    } else idx = -1

                    var l = 0f
                    var r = 0f
                    for (p in 0 until 16) {
                        val pos = playPos.get(p)
                        if (pos >= 0) {
                            val smp = samples[p]
                            if (pos < smp.size) {
                                val v = smp[pos].toFloat()
                                l += v * lGain[p]
                                r += v * rGain[p]
                                playPos.compareAndSet(p, pos, pos + 1)
                            } else playPos.compareAndSet(p, pos, -1)
                        }
                    }
                    // soft clip
                    buf[2 * i] = (tanh(l / 32768.0 * 0.9) * 32767).toInt().toShort()
                    buf[2 * i + 1] = (tanh(r / 32768.0 * 0.9) * 32767).toInt().toShort()
                }
                track.write(buf, 0, chunk * 2)
            }
            track.stop(); track.release()
        }
    }

    private fun trigger(i: Int) = playPos.set(i, 0)

    // ---------------- mic sampling ----------------
    private fun toggleMic() {
        if (micRecording) { micStop = true; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            return
        }
        startMic()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 2) {
            if (results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) startMic()
            else Toast.makeText(this, "Нужен доступ к микрофону", Toast.LENGTH_LONG).show()
        }
    }

    private fun startMic() {
        val pad = selected
        micRecording = true; micStop = false
        refresh()
        thread {
            var ar: AudioRecord? = null
            try {
                var recRate = sampleRate
                for (rate in intArrayOf(sampleRate, 44100)) {
                    val mb = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                    if (mb <= 0) continue
                    val a = AudioRecord(
                        MediaRecorder.AudioSource.MIC, rate,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(mb, 8192)
                    )
                    if (a.state == AudioRecord.STATE_INITIALIZED) { ar = a; recRate = rate; break } else a.release()
                }
                if (ar == null) throw Exception("микрофон недоступен")
                val maxLen = recRate * 5               // 5 s max
                val data = ShortArray(maxLen)
                val tmp = ShortArray(1024)
                var len = 0
                ar.startRecording()
                while (!micStop && len < maxLen && running) {
                    val n = ar.read(tmp, 0, min(tmp.size, maxLen - len))
                    if (n <= 0) break
                    System.arraycopy(tmp, 0, data, len, n)
                    len += n
                }
                ar.stop()
                val clean = processMic(data.copyOf(len), recRate)
                if (clean.isEmpty()) throw Exception("слишком тихо, попробуй ещё раз")
                val out = resample(clean, recRate)
                ui.post {
                    playPos.set(pad, -1)
                    samples[pad] = out
                    names[pad] = "MIC"
                    selected = pad
                    Toast.makeText(this, "Записано на пэд ${pad + 1}", Toast.LENGTH_SHORT).show()
                    trigger(pad)
                }
            } catch (e: Exception) {
                ui.post { Toast.makeText(this, "Запись: ${e.message}", Toast.LENGTH_LONG).show() }
            } finally {
                try { ar?.release() } catch (_: Exception) {}
                micRecording = false
                ui.post { refresh() }
            }
        }
    }

    // trim silence, normalize, short fade-out
    private fun processMic(raw: ShortArray, rate: Int): ShortArray {
        val th = 700
        var s = 0
        while (s < raw.size && abs(raw[s].toInt()) < th) s++
        var e = raw.size - 1
        while (e > s && abs(raw[e].toInt()) < th / 2) e--
        if (s >= e) return ShortArray(0)
        val start = max(0, s - rate / 200)
        val len = e - start + 1
        var peak = 1
        for (k in 0 until len) peak = max(peak, abs(raw[start + k].toInt()))
        val g = 29000.0 / peak
        val out = ShortArray(len) { (raw[start + it] * g).toInt().coerceIn(-32768, 32767).toShort() }
        val fade = min(len, rate / 30)
        for (k in 0 until fade) {
            val f = k.toDouble() / fade
            out[len - 1 - k] = (out[len - 1 - k] * f).toInt().toShort()
        }
        return out
    }

    private fun resample(mono: ShortArray, rate: Int): ShortArray {
        if (rate == sampleRate || mono.isEmpty()) return mono
        val n = (mono.size.toLong() * sampleRate / rate).toInt()
        return ShortArray(n) { k ->
            val src = k.toDouble() * rate / sampleRate
            val a = src.toInt()
            val fr = src - a
            val s0 = mono[min(a, mono.size - 1)].toInt()
            val s1 = mono[min(a + 1, mono.size - 1)].toInt()
            (s0 + (s1 - s0) * fr).toInt().toShort()
        }
    }

    // ---------------- sample decoding (wav/mp3/ogg/aac -> mono 16-bit @ engine rate) ----------------
    private fun decode(uri: Uri): ShortArray {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(this, uri, null)
            var tr = -1
            for (t in 0 until ex.trackCount) {
                if (ex.getTrackFormat(t).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")) { tr = t; break }
            }
            if (tr < 0) throw Exception("no audio track")
            ex.selectTrack(tr)
            val fmt = ex.getTrackFormat(tr)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(fmt, null, null, 0)
            codec.start()

            val info = MediaCodec.BufferInfo()
            var data = ShortArray(rate * 2)
            var len = 0
            val maxFrames = rate * 10 // cap at 10 s
            var inDone = false
            var outDone = false
            while (!outDone && len < maxFrames) {
                if (!inDone) {
                    val ib = codec.dequeueInputBuffer(10_000)
                    if (ib >= 0) {
                        val n = ex.readSampleData(codec.getInputBuffer(ib)!!, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(ib, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ib, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val ob = codec.dequeueOutputBuffer(info, 10_000)
                if (ob == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                } else if (ob >= 0) {
                    val ob2 = codec.getOutputBuffer(ob)!!
                    ob2.position(info.offset); ob2.limit(info.offset + info.size)
                    val sb = ob2.slice().order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val frames = sb.remaining() / ch
                    if (len + frames > data.size) data = data.copyOf(max(data.size * 2, len + frames))
                    for (f in 0 until frames) {
                        var sum = 0
                        for (c in 0 until ch) sum += sb.get()
                        data[len++] = (sum / ch).toShort()
                    }
                    codec.releaseOutputBuffer(ob, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
            return resample(data.copyOf(len), rate)
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            ex.release()
        }
    }

    // ---------------- UI ----------------
    private fun label(text: String, size: Float = 14f) = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun button(text: String, w: Float = 1f, onClick: () -> Unit) = label(text, 12f).apply {
        background = box(PANEL)
        layoutParams = LinearLayout.LayoutParams(0, dp(46), w).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) }
        setOnClickListener { onClick() }
    }

    private fun seek(maxV: Int, onChange: (Int) -> Unit) = SeekBar(this).apply {
        max = maxV
        progressTintList = ColorStateList.valueOf(ORANGE)
        thumbTintList = ColorStateList.valueOf(ORANGE)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(8), dp(28), dp(8), dp(8))
        }

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(label("MPS-16", 22f).apply { setTextColor(ORANGE) }, LinearLayout.LayoutParams(0, dp(46), 1f))
        bpmView = label("100 BPM", 20f)
        top.addView(bpmView, LinearLayout.LayoutParams(0, dp(46), 1f))
        root.addView(top)

        val row1 = LinearLayout(this)
        playBtn = button("▶ PLAY", 1.3f) { playing = !playing; refresh() }
        recBtn = button("● REC") { rec = !rec; refresh() }
        micBtn = button("🎤 MIC") { toggleMic() }
        loadBtn = button("LOAD") { loadMode = !loadMode; refresh() }
        mixBtn = button("MIX") { mixMode = !mixMode; refresh() }
        row1.addView(playBtn); row1.addView(recBtn); row1.addView(micBtn); row1.addView(loadBtn); row1.addView(mixBtn)
        root.addView(row1)

        val row2 = LinearLayout(this)
        row2.addView(button("BPM −") { bpm = (bpm - 2).coerceAtLeast(40); refresh() })
        row2.addView(button("BPM +") { bpm = (bpm + 2).coerceAtMost(240); refresh() })
        swingBtn = button("SWING 0") { swing = (swing + 15) % 60; refresh() }
        row2.addView(swingBtn)
        row2.addView(button("CLEAR") { pattern[selected].fill(false); refresh() })
        row2.addView(button("CLR ALL") { pattern.forEach { it.fill(false) }; refresh() })
        root.addView(row2)

        stepViews = Array(16) { s ->
            label("${s + 1}", 12f).apply {
                setOnClickListener { pattern[selected][s] = !pattern[selected][s]; refresh() }
            }
        }
        for (r in 0 until 2) {
            val l = LinearLayout(this)
            for (c in 0 until 8) {
                l.addView(stepViews[r * 8 + c], LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
            }
            root.addView(l)
        }

        // mixer panel (for the selected pad)
        mixPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(PANEL, 0, 12)
            setPadding(dp(10), dp(6), dp(10), dp(6))
            visibility = View.GONE
        }
        mixTitle = label("", 13f)
        mixPanel.addView(mixTitle)
        volBar = seek(120) { p -> vol[selected] = p / 100f; updateGain(selected); refresh() }
        panBar = seek(100) { p ->
            pan[selected] = if (abs(p - 50) <= 3) 0f else (p - 50) / 50f
            updateGain(selected); refresh()
        }
        val volRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        volRow.addView(label("VOL", 12f), LinearLayout.LayoutParams(dp(40), LinearLayout.LayoutParams.WRAP_CONTENT))
        volRow.addView(volBar, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val panRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        panRow.addView(label("PAN", 12f), LinearLayout.LayoutParams(dp(40), LinearLayout.LayoutParams.WRAP_CONTENT))
        panRow.addView(panBar, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        mixPanel.addView(volRow)
        mixPanel.addView(panRow)
        root.addView(mixPanel, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { setMargins(dp(2), dp(4), dp(2), dp(4)) })

        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        padViews = Array(16) { i ->
            label(names[i], 13f).apply { setOnTouchListener { v, e -> onPad(i, v, e); true } }
        }
        for (r in 3 downTo 0) {
            val l = LinearLayout(this)
            for (c in 0 until 4) {
                l.addView(padViews[r * 4 + c], LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                    .apply { setMargins(dp(4), dp(4), dp(4), dp(4)) })
            }
            grid.addView(l, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        root.addView(grid, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun onPad(i: Int, v: View, e: MotionEvent) {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                v.alpha = 0.55f
                selected = i
                if (loadMode) {
                    pickingPad = i
                    startActivityForResult(
                        Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                            addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
                        }, 1
                    )
                } else {
                    trigger(i)
                    if (rec && playing) recordHit(i)
                }
                refresh()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.alpha = 1f
        }
    }

    private fun recordHit(pad: Int) {
        var s = step
        if (System.nanoTime() - lastStepNs > curStepNs / 2) s = (s + 1) % 16
        pattern[pad][s] = true
    }

    private fun panText(p: Float): String = when {
        p == 0f -> "C"
        p < 0f -> "L${(-p * 100).toInt()}"
        else -> "R${(p * 100).toInt()}"
    }

    private fun refresh() {
        bpmView.text = "$bpm BPM"
        playBtn.text = if (playing) "■ STOP" else "▶ PLAY"
        playBtn.background = box(if (playing) Color.parseColor("#2E7D32") else PANEL)
        recBtn.background = box(if (rec) RED else PANEL)
        micBtn.text = if (micRecording) "■ REC…" else "🎤 MIC"
        micBtn.background = box(if (micRecording) RED else PANEL)
        loadBtn.background = box(if (loadMode) ORANGE else PANEL)
        mixBtn.background = box(if (mixMode) ORANGE else PANEL)
        swingBtn.text = "SWING $swing"

        mixPanel.visibility = if (mixMode) View.VISIBLE else View.GONE
        mixTitle.text = "${names[selected]}   VOL ${(vol[selected] * 100).toInt()}%   PAN ${panText(pan[selected])}"
        val vp = (vol[selected] * 100).toInt()
        if (volBar.progress != vp) volBar.progress = vp
        val pp = ((pan[selected] + 1f) * 50f).toInt()
        if (panBar.progress != pp) panBar.progress = pp

        for (i in 0 until 16) {
            padViews[i].text = if (mixMode) "${names[i]}\n${(vol[i] * 100).toInt()}" else names[i]
            padViews[i].background = box(PAD_COLORS[(i / 4 + i % 4) % 4], if (i == selected) Color.WHITE else 0, 14)
        }
        for (s in 0 until 16) {
            val on = pattern[selected][s]
            val cur = playing && s == step
            stepViews[s].background = box(
                if (on) ORANGE else PANEL,
                if (cur) Color.WHITE else if (s % 4 == 0) Color.parseColor("#555560") else 0, 8
            )
        }
    }

    override fun onPause() { playing = false; micStop = true; super.onPause() }

    override fun onDestroy() {
        playing = false
        micStop = true
        running = false
        audioThread?.join(500)
        super.onDestroy()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri: Uri = data?.data ?: return
        if (requestCode != 1 || resultCode != RESULT_OK || pickingPad < 0) return
        val i = pickingPad
        thread {
            try {
                val pcm = decode(uri)
                if (pcm.isEmpty()) throw Exception("empty sample")
                var nm = names[i]
                contentResolver.query(uri, null, null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME))
                        nm = n.substringBeforeLast('.').take(8).uppercase()
                    }
                }
                ui.post {
                    playPos.set(i, -1)
                    samples[i] = pcm
                    names[i] = nm
                    loadMode = false
                    Toast.makeText(this, "Sample loaded on pad ${i + 1}", Toast.LENGTH_SHORT).show()
                    refresh()
                }
            } catch (e: Exception) {
                ui.post { Toast.makeText(this, "Load failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    // ---------------- built-in drum synth ----------------
    private fun synth(k: Int): ShortArray {
        val sr = sampleRate
        val dur = when (k) {
            0 -> 0.45; 1 -> 0.25; 2 -> 0.06; 3 -> 0.35; 4 -> 0.25; 5, 6 -> 0.3; 7 -> 0.05
            8 -> 0.3; 9 -> 1.0; 10, 11 -> 0.6; 12 -> 0.15; 13 -> 0.3; 14 -> 0.3; else -> 0.12
        }
        val n = (sr * dur).toInt()
        val out = ShortArray(n)
        val rnd = java.util.Random(k.toLong())
        var ph = 0.0; var ph2 = 0.0; var prev = 0.0
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            val x = i / n.toDouble()
            val noise = rnd.nextDouble() * 2 - 1
            val hp = noise - prev; prev = noise
            val v: Double = when (k) {
                0 -> { ph += 2 * PI * (45 + 120 * exp(-t * 28)) / sr; sin(ph) * exp(-t * 7) + if (t < 0.004) 0.4 else 0.0 }
                1 -> { ph += 2 * PI * 190 / sr; sin(ph) * 0.5 * exp(-t * 20) + noise * 0.7 * exp(-t * 18) }
                2 -> hp * exp(-t * 70) * 0.8
                3 -> hp * exp(-t * 9) * 0.7
                4 -> noise * (if (t < 0.036) exp(-(t % 0.012) * 300) else exp(-(t - 0.036) * 25)) * 0.9
                5 -> { ph += 2 * PI * (110 + 90 * exp(-t * 20)) / sr; sin(ph) * exp(-t * 9) }
                6 -> { ph += 2 * PI * (170 + 120 * exp(-t * 20)) / sr; sin(ph) * exp(-t * 9) }
                7 -> { ph += 2 * PI * 1700 / sr; (if (sin(ph) >= 0) 1.0 else -1.0) * exp(-t * 90) * 0.4 + noise * 0.3 * exp(-t * 90) }
                8 -> {
                    ph += 2 * PI * 560 / sr; ph2 += 2 * PI * 845 / sr
                    ((if (sin(ph) >= 0) 1.0 else -1.0) + (if (sin(ph2) >= 0) 1.0 else -1.0)) * 0.25 * exp(-t * 12)
                }
                9 -> hp * exp(-t * 3.5) * 0.6
                10 -> { ph += 2 * PI * 55 / sr; tanh(2 * sin(ph)) * exp(-t * 3.5) }
                11 -> { ph += 2 * PI * 41 / sr; (sin(ph) + 0.3 * sin(2 * ph)) * exp(-t * 4) * 0.8 }
                12 -> { ph += 2 * PI * (300 + 600 * exp(-t * 25)) / sr; sin(ph) * exp(-t * 20) }
                13 -> { ph += 2 * PI * (100 + 2000 * exp(-t * 12)) / sr; sin(ph) * exp(-t * 6) }
                14 -> { ph += 2 * PI * (260 + 40 * exp(-t * 30)) / sr; sin(ph) * exp(-t * 14) * 0.9 }
                else -> hp * sin(PI * x) * 0.5
            }
            out[i] = (v.coerceIn(-1.0, 1.0) * 30000).toInt().toShort()
        }
        return out
    }
}
