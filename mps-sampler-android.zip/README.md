# MPS Sampler (Android)
MPC/MPS-style sampler: 16 pads, 16-step sequencer, BPM, swing, live REC, load your own samples.

## Build APK
- Android Studio: open folder -> Build > Build APK(s)
- or GitHub: push repo -> Actions -> "Build APK" -> download artifact (debug APK)

## Use
- Tap pad = play + select it. Row of 16 steps = pattern for selected pad.
- PLAY/STOP, REC (tap pads while playing -> quantized into pattern), CLEAR (selected pad's steps; long list: CLR ALL).
- LOAD: toggle, then tap a pad and pick an audio file (keep samples short, decoded to mono, max 10 s).
- BPM -/+ , SWING cycles 0/15/30/45 %.
Code: app/src/main/java/com/mps/sampler/MainActivity.kt (single file).

## v2
- MIC: tap 🎤 MIC (grant permission), make a sound, tap again (max 5 s) -> trimmed, normalized, loaded on the selected pad and played.
- MIX: per-pad VOL (0-120%) and PAN (equal-power, stereo output) sliders for the selected pad; pads show their volume while MIX is on.
- Engine: stereo AudioTrack (LOW_LATENCY), sample-accurate sequencer in the render loop, soft clip.
